#!/bin/bash
echo "Installing raspdac and its dependencies"

#requred to end the plugin install
echo "plugininstallend"
